create table colegio
(
    id                       int auto_increment
        primary key,
    rbd                      varchar(11)                  not null,
    nombre                   varchar(100) charset utf8    null,
    webclass                 bit                          null,
    anio_actual              year          default '2022' null,
    curriculum               int                          null,
    direccion                varchar(100)                 null,
    telefonoColegio          varchar(24)                  null,
    correoColegio            varchar(128)                 null,
    idRegion                 int                          null,
    idCiudad                 int                          null,
    url                      varchar(200)                 null,
    visible                  int                          not null,
    modulos                  int(15)       default 42     null,
    creacion                 int                          not null,
    encargado                int           default 0      not null,
    id_ant                   int           default 0      not null,
    semilla                  varchar(64)                  null,
    estado_comercial         int           default 0      not null,
    cuenta_wm                varchar(45)                  null,
    pass_wm                  varchar(250)                 null,
    pseudo                   varchar(100)                 null,
    grupo_wc                 int                          null,
    basePromedioCritico      decimal(2, 1) default 4.0    not null,
    baseAsistenciaCritica    int           default 85     not null,
    umbral_asistencia_bloque double        default 0.6    not null,
    tema_institucional       int           default 0      not null,
    fecha_activacion         int                          null,
    fecha_caducidad          int                          null,
    fecha_venta              int                          null,
    codigo_activacion        varchar(25)                  null,
    numero_matriculados      int                          null comment 'Este dato a la cantidad inicial de alumnos matriculados',
    constraint codigo_activacion
        unique (codigo_activacion),
    constraint FK_AA00D8767BE2A7C3
        foreign key (curriculum) references curriculum (id),
    constraint FK_AA00D876D6A69A7F
        foreign key (grupo_wc) references grupo_wc (id),
    constraint FK_encargado
        foreign key (encargado) references colegio_encargado (id)
)
    collate = utf8_spanish_ci;

create index IDX_AA00D876D6A69A7F
    on colegio (grupo_wc);

create index fk_curriculum
    on colegio (curriculum);

create index fk_encargado
    on colegio (encargado);

create index nombre_idx
    on colegio (nombre);

create index rbd_idx
    on colegio (rbd);

INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (20, '', 'Desarrollo', null, 2021, 1, 'Tarapaca 1016', null, null, null, null, 'supercolegio.webescuela.cl', 1, 68809083, 1357009200, 1, 0, '0', 0, null, null, null, null, 4.0, 85, 0.6, 0, null, null, null, null, null);
INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (21, '12', 'Testing Didactica', null, 2021, 1032, 'Tarapaca 1016', null, null, null, null, 'supercolegio.webescuela.cl', 1, 69205883, 1357009200, 1, 0, '0', 0, null, null, '', null, 4.0, 85, 0.6, 0, null, null, null, null, null);
INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (22, '4042222', 'WebClass Presentación', null, 2022, 1787, 'Milan 1221, Dpto 1501..', '78954123', 'fewf@gregre.com', 75, 13101, 'demo.webescuela.cl', 1, 935329791, 1357009200, 1, 0, '0', 0, 'demowebescuela', 'zNXYsNmYldXNxAjMzdXZupCbpFWbfN3chBnK', '', 11, 4.5, 90, 0.3, 0, null, null, null, null, null);
INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (23, '1', 'Demo', null, 2022, 1, 'Tarapaca 1016', '', 'webclass@webclass.com', 75, 13101, 'supercolegio.webescuela.cl', 1, 935329791, 1357009200, 1, 0, 'CREDENCIALES NOK', 0, null, null, '', null, 5.0, 90, 0, 0, null, null, null, null, null);
INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (24, '9998', 'Capacitación interna', null, 2021, 115, 'Tarapaca 1016', null, null, null, null, 'supercolegio.webescuela.cl', 1, 68809211, 1357009200, 1, 0, '0', 0, null, null, '', null, 4.0, 85, 0.6, 0, null, null, null, null, null);
INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (25, '', 'Colegio Profesores', null, 2021, 1, 'Tarapaca 1016', null, null, null, null, 'supercolegio.webescuela.cl', 1, 68809083, 1357009200, 1, 0, '0', 0, null, null, null, null, 4.0, 85, 0.6, 0, null, null, null, null, null);
INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (26, '0000000000', 'Desafío ciencias', true, 2021, 1, '', null, null, null, null, 'www.go.cl', 1, 389627, 1625501764, 0, 0, null, 0, null, null, 'Gomath', null, 4.0, 85, 0.6, 0, null, null, null, null, null);
INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (27, '0000000000', 'Desafío lectura', true, 2021, 1, '', null, null, null, null, 'www.go.cl', 1, 913915, 1625501764, 0, 0, null, 0, null, null, 'Gomath', null, 4.0, 85, 0.6, 0, null, null, null, null, null);
INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (31, '', 'Colegio de Prueba', null, 2021, 460, 'Tarapaca 1016', null, null, null, null, 'alfa.webclasslms.cl', 1, 68809083, 1357009200, 1, 0, '0', 0, null, null, null, null, 4.0, 85, 0.6, 0, null, null, null, null, null);
INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (32, '111132', 'Capacitación', null, 2021, 6, 'Tarapaca 1016', null, null, null, null, 'alfa.webclasslms.cl', 1, 69202427, 1357009200, 1, 0, '0', 0, null, null, 'Colegio THB', null, 4.0, 85, 0.6, 0, null, null, null, null, null);
INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (40, '', 'Colegio Adm. de encuestas', null, 2021, 1, 'Tarapaca 1016', null, null, null, null, 'supercolegio.webclaslms.cl', 1, 655360, 1406661611, 1, 0, '0', 0, null, null, null, null, 4.0, 85, 0.6, 0, null, null, null, null, null);
INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (41, '11111-1', 'Colegio News', null, 2021, 1, '', null, null, null, null, 'news.webescuela.cl', 1, 67403913, 1464022516, 0, 0, null, 0, 'demowebescuela', null, '', null, 4.0, 85, 0.6, 4041, null, null, null, null, null);
INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (45, '11111', 'Colegio 45', null, 2021, 1030, 'colegio 45', null, null, null, null, '', 1, 68932091, 1458314492, 0, 0, null, 0, null, null, '', null, 4.0, 85, 0.6, 0, null, null, null, null, null);
INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (50, '12345', 'Evaluaciones WebClass', null, 2021, 1, 'Tarapaca 1016', null, null, null, null, 'Antonia', 1, 68940283, 0, 0, 0, null, 0, '221553519', '==QN0MjMxoCbpFWbfN3chBnK', null, null, 4.0, 85, 0.6, 0, null, null, null, null, null);
INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (60, '0000', 'Promocion', null, 2021, 1, '', null, null, null, null, 'webclass.com', 1, 67108865, 1452257143, 0, 0, null, 0, null, null, 'Promocion', null, 4.0, 85, 0.6, 0, null, null, null, null, null);
INSERT INTO webclass_produccion.colegio (id, rbd, nombre, webclass, anio_actual, curriculum, direccion, telefonoColegio, correoColegio, idRegion, idCiudad, url, visible, modulos, creacion, encargado, id_ant, semilla, estado_comercial, cuenta_wm, pass_wm, pseudo, grupo_wc, basePromedioCritico, baseAsistenciaCritica, umbral_asistencia_bloque, tema_institucional, fecha_activacion, fecha_caducidad, fecha_venta, codigo_activacion, numero_matriculados) VALUES (65, '', 'colegio para niños sin colegio :&#34;(', null, null, 0, null, null, null, null, null, null, 0, 42, 0, 0, 0, null, 0, null, null, null, null, 4.0, 85, 0.6, 0, null, null, null, null, null);